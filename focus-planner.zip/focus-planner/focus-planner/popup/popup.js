import { SOUNDS, SoundEngine } from '../lib/sounds.js';
import { parseApp, quickApp, QUICK_APPS, appKey, faviconUrl } from '../lib/apps.js';
import { DEFAULT_SETTINGS, DURATION_PRESETS, EMERGENCY_PHRASE, phraseMatches } from '../lib/defaults.js';

const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => [...document.querySelectorAll(sel)];
const send = (type, data = {}) => chrome.runtime.sendMessage({ target: 'background', type, ...data });

function el(tag, props = {}, ...children) {
  const node = document.createElement(tag);
  for (const [k, v] of Object.entries(props)) {
    if (k === 'class') node.className = v;
    else if (k === 'dataset') Object.assign(node.dataset, v);
    else if (k.startsWith('on')) node.addEventListener(k.slice(2), v);
    else if (v !== undefined && v !== null && v !== false) node.setAttribute(k, v === true ? '' : v);
  }
  for (const c of children.flat()) if (c != null) node.append(c);
  return node;
}

const state = {
  step: 1,
  draft: null, // { task, apps, minutes, sound, volume, openApps, groupTabs }
  settings: { ...DEFAULT_SETTINGS },
  session: null,
  history: [],
  showHistory: false,
  ending: false,
  ticked: new Set(), // desktop apps ticked off during a session (popup-local)
  incognitoOk: true, // is the extension allowed in incognito?
  incognitoSkipped: false,
};

const preview = new SoundEngine();
let previewing = null;
let ticker = null;

init();

// ---------------------------------------------------------------- init

async function init() {
  const stored = await chrome.storage.local.get(['settings', 'session', 'draft', 'history', 'ticked']);
  state.settings = { ...DEFAULT_SETTINGS, ...(stored.settings || {}) };
  state.session = stored.session || null;
  state.history = stored.history || [];
  const sameSession = state.session && stored.ticked?.sessionId === state.session.id;
  state.ticked = new Set(sameSession ? stored.ticked.keys : []);
  state.draft = {
    task: '',
    apps: [],
    minutes: state.settings.defaultMinutes,
    sound: state.settings.sound,
    volume: state.settings.volume,
    openApps: state.settings.openApps,
    groupTabs: state.settings.groupTabs,
    lock: state.settings.lockBrowsing,
    strict: state.settings.strictMode,
    ...(stored.draft || {}),
  };
  state.step = stored.draft?.step || 1;

  state.incognitoOk = await chrome.extension.isAllowedIncognitoAccess();
  wireSetup();
  wireSession();
  wireOutcome();
  wireHistory();
  render();

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    if (changes.settings) state.settings = { ...DEFAULT_SETTINGS, ...(changes.settings.newValue || {}) };
    if (changes.history) state.history = changes.history.newValue || [];
    if (changes.session) {
      const prevId = state.session?.id;
      state.session = changes.session.newValue || null;
      if (state.session?.id !== prevId) state.ticked = new Set();
      state.ending = false;
      render();
    } else if (changes.history && state.showHistory) {
      renderHistory();
    }
  });
}

function saveDraft() {
  chrome.storage.local.set({ draft: { ...state.draft, step: state.step } });
}

// ---------------------------------------------------------------- routing

function render() {
  const s = state.session;
  let view = 'setup';
  if (state.showHistory) view = 'history';
  else if (s && (s.status === 'timeup' || state.ending)) view = 'outcome';
  else if (s) view = 'session';

  for (const v of ['setup', 'session', 'outcome', 'history']) $(`#view-${v}`).hidden = v !== view;
  clearInterval(ticker);

  if (view !== 'setup') stopPreview();
  if (view === 'setup') renderSetup();
  if (view === 'session') {
    renderSession();
    ticker = setInterval(tick, 250);
  }
  if (view === 'outcome') renderOutcome();
  if (view === 'history') renderHistory();
}

// ---------------------------------------------------------------- setup wizard

function wireSetup() {
  $('#task').addEventListener('input', (e) => {
    state.draft.task = e.target.value;
    saveDraft();
  });
  $('#task').addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      goStep(2);
    }
  });
  $('#to-step-2').addEventListener('click', () => goStep(2));
  $('#to-step-3').addEventListener('click', () => goStep(3));
  $$('[data-back]').forEach((b) => b.addEventListener('click', () => goStep(state.step - 1)));

  $('#add-app-form').addEventListener('submit', (e) => {
    e.preventDefault();
    const input = $('#app-input');
    // Allow several at once: "gmail, notion, vs code"
    input.value.split(/[,\n]/).forEach((part) => addApp(parseApp(part)));
    input.value = '';
    input.focus();
  });
  $('#open-apps').addEventListener('change', (e) => {
    state.draft.openApps = e.target.checked;
    $('#group-tabs').disabled = !e.target.checked;
    saveDraft();
  });
  $('#lock').addEventListener('change', (e) => {
    state.draft.lock = e.target.checked;
    $('#strict').disabled = !e.target.checked;
    saveDraft();
  });
  $('#strict').addEventListener('change', (e) => {
    state.draft.strict = e.target.checked;
    saveDraft();
  });
  $('#incog-fix').addEventListener('click', () => chrome.tabs.create({ url: `chrome://extensions/?id=${chrome.runtime.id}` }));
  $('#incog-skip').addEventListener('click', () => {
    state.incognitoSkipped = true;
    renderSetup();
  });
  $('#group-tabs').addEventListener('change', (e) => {
    state.draft.groupTabs = e.target.checked;
    saveDraft();
  });

  $('#custom-minutes').addEventListener('input', (e) => {
    const m = Math.round(Number(e.target.value));
    if (m >= 1 && m <= 480) {
      state.draft.minutes = m;
      saveDraft();
      renderDurations();
    }
  });
  $('#volume').addEventListener('input', (e) => {
    state.draft.volume = Number(e.target.value) / 100;
    preview.setVolume(state.draft.volume);
    saveDraft();
  });
  $('#start').addEventListener('click', startFocus);
}

function goStep(n) {
  if (n === 2 && !state.draft.task.trim()) {
    $('#task').focus();
    $('#task').placeholder = 'Type your task first — what are you working on?';
    return;
  }
  state.step = Math.min(Math.max(n, 1), 3);
  saveDraft();
  renderSetup();
  if (state.step === 2) $('#app-input').focus();
}

function renderSetup() {
  const d = state.draft;
  $$('.steps li').forEach((li) => {
    const n = Number(li.dataset.step);
    li.classList.toggle('active', n === state.step);
    li.classList.toggle('done', n < state.step);
  });
  $$('section.step').forEach((sec) => (sec.hidden = Number(sec.dataset.step) !== state.step));

  if (state.step === 1) {
    $('#task').value = d.task;
    const recent = [...new Set(state.history.map((h) => h.task))].slice(0, 4);
    $('#recent-tasks').replaceChildren(
      ...recent.map((t) =>
        el('button', { class: 'chip recent', title: t, onclick: () => ((d.task = t), saveDraft(), renderSetup()) }, t),
      ),
    );
    requestAnimationFrame(() => $('#task').focus());
  }

  if (state.step === 2) {
    renderAppList();
    $('#open-apps').checked = d.openApps;
    $('#group-tabs').checked = d.groupTabs;
    $('#group-tabs').disabled = !d.openApps;
    $('#lock').checked = !!d.lock;
    $('#strict').checked = !!d.strict;
    $('#strict').disabled = !d.lock;
  }

  if (state.step === 3) {
    renderDurations();
    renderSoundGrid();
    $('#volume').value = Math.round(d.volume * 100);
    $('#setup-error').hidden = true;
    // Incognito windows are invisible to the lock unless the user allows it.
    const loophole = d.lock && !state.incognitoOk && !state.incognitoSkipped;
    $('#incog-warn').hidden = !loophole;
    $('#start').disabled = loophole && !!d.strict;
  }
}

function addApp(app) {
  if (!app) return;
  if (state.draft.apps.some((a) => appKey(a) === appKey(app))) return;
  state.draft.apps.push(app);
  saveDraft();
  renderAppList();
}

function appIcon(app) {
  return app.type === 'web'
    ? el('img', { class: 'fav', src: faviconUrl(app.url), alt: '' })
    : el('span', { class: 'fav', 'aria-hidden': 'true' }, '🖥️');
}

function renderAppList() {
  const apps = state.draft.apps;
  $('#app-list').replaceChildren(
    ...apps.map((app, i) =>
      el(
        'li',
        {},
        appIcon(app),
        el('span', { class: 'name', title: app.url || app.name }, app.name),
        el('span', { class: 'tag' }, app.type === 'web' ? 'opens in tab' : 'reminder'),
        el(
          'button',
          {
            class: 'x',
            title: 'Remove',
            'aria-label': `Remove ${app.name}`,
            onclick: () => {
              apps.splice(i, 1);
              saveDraft();
              renderAppList();
            },
          },
          '×',
        ),
      ),
    ),
  );
  $('#apps-empty').hidden = apps.length > 0;

  // Quick-add chips: recently used first, then common web apps.
  const have = new Set(apps.map(appKey));
  const recent = state.settings.recentApps.filter((a) => !have.has(appKey(a)));
  const common = QUICK_APPS.map(quickApp).filter(
    (a) => a && !have.has(appKey(a)) && !recent.some((r) => appKey(r) === appKey(a)),
  );
  const chips = [
    ...recent.slice(0, 6).map((a) => ({ app: a, recent: true })),
    ...common.map((a) => ({ app: a, recent: false })),
  ].slice(0, 10);
  $('#quick-apps').replaceChildren(
    ...chips.map(({ app, recent }) =>
      el('button', { class: `chip${recent ? ' recent' : ''}`, title: app.url || 'Desktop app', onclick: () => addApp(app) }, `+ ${app.name}`),
    ),
  );
}

function renderDurations() {
  const m = state.draft.minutes;
  $('#durations').replaceChildren(
    ...DURATION_PRESETS.map((p) =>
      el(
        'button',
        {
          class: `dur${p === m ? ' selected' : ''}`,
          'aria-pressed': String(p === m),
          onclick: () => {
            state.draft.minutes = p;
            $('#custom-minutes').value = '';
            saveDraft();
            renderDurations();
          },
        },
        String(p),
        el('small', {}, 'min'),
      ),
    ),
  );
  if (!DURATION_PRESETS.includes(m)) $('#custom-minutes').value = m;
}

function renderSoundGrid() {
  $('#sounds').replaceChildren(
    ...SOUNDS.map((s) => {
      const selected = state.draft.sound === s.id;
      const card = el(
        'div',
        {
          class: `sound${selected ? ' selected' : ''}`,
          role: 'radio',
          tabindex: '0',
          'aria-checked': String(selected),
          onclick: () => selectSound(s.id),
          onkeydown: (e) => (e.key === 'Enter' || e.key === ' ') && (e.preventDefault(), selectSound(s.id)),
        },
        el('span', { class: 'ic', 'aria-hidden': 'true' }, s.icon),
        el('span', {}, el('span', { class: 't' }, s.name), el('span', { class: 'd' }, s.desc)),
      );
      if (s.id !== 'none') {
        card.append(
          el(
            'button',
            {
              class: `play${previewing === s.id ? ' on' : ''}`,
              title: previewing === s.id ? 'Stop preview' : 'Preview',
              'aria-label': `Preview ${s.name}`,
              onclick: (e) => {
                e.stopPropagation();
                togglePreview(s.id);
              },
            },
            previewing === s.id ? '■' : '▶',
          ),
        );
      }
      return card;
    }),
  );
}

function selectSound(id) {
  state.draft.sound = id;
  saveDraft();
  if (previewing && previewing !== id && id !== 'none') togglePreview(id);
  else if (id === 'none') stopPreview();
  renderSoundGrid();
}

async function togglePreview(id) {
  if (previewing === id) return stopPreview();
  previewing = id;
  state.draft.sound = id;
  saveDraft();
  renderSoundGrid();
  const res = await preview.play(id, state.draft.volume);
  if (!res.ok && res.error !== 'superseded') {
    showError('#setup-error', res.error);
    stopPreview();
  }
}

function stopPreview() {
  if (!previewing) return;
  previewing = null;
  preview.stop(0.3);
  if (!$('#view-setup').hidden && state.step === 3) renderSoundGrid();
}

async function startFocus() {
  const d = state.draft;
  if (!d.task.trim()) return goStep(1);
  stopPreview();
  $('#start').disabled = true;
  const res = await send('start', {
    plan: {
      task: d.task.trim(),
      apps: d.apps,
      minutes: d.minutes,
      sound: d.sound,
      volume: d.volume,
      openApps: d.openApps,
      groupTabs: d.groupTabs,
      lock: !!d.lock,
      strict: !!(d.lock && d.strict),
    },
  }).catch((e) => ({ ok: false, error: String(e) }));
  renderSetup();
  if (!res?.ok) return showError('#setup-error', res?.error || 'Could not start the timer.');
  // Reset the wizard for next time; the session view takes over via storage.onChanged.
  state.step = 1;
  state.draft = { ...d, task: '', apps: [] };
  await chrome.storage.local.remove('draft');
  if (res.music && res.music.ok === false) showError('#session-error', res.music.error);
}

function showError(sel, msg) {
  const p = $(sel);
  p.textContent = msg;
  p.hidden = !msg;
}

// ---------------------------------------------------------------- session

function wireSession() {
  $('#pause').addEventListener('click', () => send(state.session?.status === 'paused' ? 'resume' : 'pause'));
  $('#plus5').addEventListener('click', () => send('extend', { minutes: 5 }));
  $('#end').addEventListener('click', () => {
    state.ending = true;
    render();
  });
  $('#session-sound').replaceChildren(...SOUNDS.map((s) => el('option', { value: s.id }, `${s.icon}  ${s.name}`)));
  $('#session-sound').addEventListener('change', async (e) => {
    const res = await send('setSound', { sound: e.target.value });
    showError('#session-error', res?.music && res.music.ok === false ? res.music.error : '');
  });
  let volTimer;
  $('#session-volume').addEventListener('input', (e) => {
    clearTimeout(volTimer);
    const volume = Number(e.target.value) / 100;
    volTimer = setTimeout(() => send('setVolume', { volume }), 60);
  });
  $('#reopen-all').addEventListener('click', () => send('openApps', { apps: state.session?.apps || [], task: null }));
}

function renderSession() {
  const s = state.session;
  const paused = s.status === 'paused';
  $('#view-session').classList.toggle('paused', paused);
  $('#session-status').textContent = paused ? 'Paused' : 'Focusing on';
  $('#session-task').textContent = s.task;
  $('#pause').textContent = paused ? 'Resume' : 'Pause';
  const n = (s.allowedHosts || []).length;
  $('#lock-pill').hidden = !s.lock;
  $('#pause').hidden = !!s.strict;
  $('#end').textContent = s.strict ? 'Emergency exit' : 'End';
  $('#lock-pill').textContent = paused
    ? '🔓 Focus lock off while paused'
    : `${s.strict ? '💪 Strict focus' : '🔒 Focus lock on'} · ${n} allowed site${n === 1 ? '' : 's'}`;
  $('#lock-pill').title = (s.allowedHosts || []).join(', ');
  $('#session-sound').value = s.sound;
  $('#session-volume').value = Math.round(s.volume * 100);

  const apps = s.apps || [];
  $('#session-apps-panel').hidden = apps.length === 0;
  $('#reopen-all').hidden = !apps.some((a) => a.type === 'web');
  $('#session-apps').replaceChildren(
    ...apps.map((app) => {
      if (app.type === 'web') {
        return el(
          'li',
          {},
          appIcon(app),
          el('span', { class: 'name', title: app.url }, app.name),
          el('button', { class: 'link open', onclick: () => chrome.tabs.create({ url: app.url }) }, 'Open'),
        );
      }
      const key = appKey(app);
      const done = state.ticked.has(key);
      return el(
        'li',
        { class: done ? 'ticked' : '' },
        appIcon(app),
        el('span', { class: 'name' }, app.name),
        el(
          'label',
          { class: 'tag', title: 'Tick once you have it open' },
          el('input', {
            type: 'checkbox',
            checked: done,
            onchange: (e) => {
              e.target.checked ? state.ticked.add(key) : state.ticked.delete(key);
              chrome.storage.local.set({ ticked: { sessionId: s.id, keys: [...state.ticked] } });
              renderSession();
            },
          }),
          ' open',
        ),
      );
    }),
  );
  tick();
}

function remaining(s) {
  return s.status === 'running' ? Math.max(0, s.endsAt - Date.now()) : s.remainingMs ?? 0;
}

function fmt(ms) {
  const total = Math.ceil(ms / 1000);
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const sec = total % 60;
  const mm = h ? String(m).padStart(2, '0') : String(m);
  return `${h ? `${h}:` : ''}${mm}:${String(sec).padStart(2, '0')}`;
}

function tick() {
  const s = state.session;
  if (!s) return;
  const rem = remaining(s);
  $('#time').textContent = fmt(rem);
  const C = 2 * Math.PI * 54;
  const bar = $('#ring-bar');
  bar.style.strokeDasharray = String(C);
  bar.style.strokeDashoffset = String(C * (1 - rem / s.totalMs));
  $('#ends-at').textContent =
    s.status === 'paused'
      ? 'paused'
      : `ends ${new Date(s.endsAt).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })}`;
}

// ---------------------------------------------------------------- outcome

function wireOutcome() {
  const finish = async (outcome) => {
    const res = await send('finish', { outcome, phrase: $('#phrase-input').value });
    if (!res?.ok) $('#phrase-input').focus();
  };
  $('#outcome-done').addEventListener('click', () => finish('done'));
  $('#outcome-stop').addEventListener('click', () => finish('stopped'));
  $('#phrase').textContent = EMERGENCY_PHRASE;
  $('#phrase-input').addEventListener('input', renderOutcome);
  // No pasting the phrase — typing it is the point.
  $('#phrase-input').addEventListener('paste', (e) => e.preventDefault());
  $('#outcome-cancel').addEventListener('click', () => {
    state.ending = false;
    render();
  });
  $$('[data-extend]').forEach((b) =>
    b.addEventListener('click', () => send('extend', { minutes: Number(b.dataset.extend) })),
  );
}

function renderOutcome() {
  const s = state.session;
  const timeUp = s.status === 'timeup';
  $('#outcome-emoji').textContent = timeUp ? '🎉' : '🏁';
  $('#outcome-title').textContent = timeUp ? "Time's up — nice focus!" : 'Wrap up this session?';
  $('#outcome-task').textContent = s.task;
  $('#outcome-extend').hidden = !timeUp;
  $('#outcome-cancel').hidden = timeUp;
  const locked = !timeUp && !!s.strict;
  $('#emergency').hidden = !locked;
  const ok = !locked || phraseMatches($('#phrase-input').value);
  $('#outcome-done').disabled = !ok;
  $('#outcome-stop').disabled = !ok;
  if (!locked) $('#phrase-input').value = '';
  else if (document.activeElement !== $('#phrase-input')) $('#phrase-input').focus();
}

// ---------------------------------------------------------------- history

function wireHistory() {
  $('#nav-history').addEventListener('click', () => {
    state.showHistory = !state.showHistory;
    render();
  });
  $('#history-back').addEventListener('click', () => {
    state.showHistory = false;
    render();
  });
  $('#nav-settings').addEventListener('click', () => chrome.runtime.openOptionsPage());
}

function dur(ms) {
  const min = Math.round(ms / 60000);
  if (min < 60) return `${min}m`;
  return `${Math.floor(min / 60)}h ${String(min % 60).padStart(2, '0')}m`;
}

function renderHistory() {
  const h = state.history;
  const startOfDay = new Date().setHours(0, 0, 0, 0);
  const weekAgo = Date.now() - 7 * 864e5;
  const today = h.filter((x) => x.endedAt >= startOfDay);
  const week = h.filter((x) => x.endedAt >= weekAgo);
  const sum = (arr) => arr.reduce((a, x) => a + x.focusedMs, 0);
  $('#stats').replaceChildren(
    el('div', { class: 'stat' }, el('b', {}, dur(sum(today))), el('span', {}, 'today')),
    el('div', { class: 'stat' }, el('b', {}, dur(sum(week))), el('span', {}, 'this week')),
    el('div', { class: 'stat' }, el('b', {}, String(week.filter((x) => x.outcome === 'done').length)), el('span', {}, 'tasks done (7d)')),
  );
  const label = { done: 'Finished', stopped: 'Stopped', timeup: 'Time up' };
  $('#history-list').replaceChildren(
    ...h.slice(0, 50).map((x) =>
      el(
        'li',
        {},
        el('div', { class: 'h-task' }, x.task),
        el(
          'div',
          { class: 'h-meta' },
          el('span', { class: `badge ${x.outcome}` }, label[x.outcome] || x.outcome),
          el('span', {}, dur(x.focusedMs)),
          el(
            'span',
            {},
            new Date(x.endedAt).toLocaleString([], { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' }),
          ),
        ),
      ),
    ),
  );
  $('#history-empty').hidden = h.length > 0;
}
