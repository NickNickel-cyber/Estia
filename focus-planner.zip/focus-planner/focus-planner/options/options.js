import { SOUNDS, SoundEngine } from '../lib/sounds.js';
import { DEFAULT_SETTINGS } from '../lib/defaults.js';
import { saveCustomAudio, getCustomAudio, clearCustomAudio } from '../lib/audio-store.js';
import { faviconUrl } from '../lib/apps.js';
import { normalizeHost } from '../lib/lock.js';

const $ = (s) => document.querySelector(s);
const MAX_BYTES = 100 * 1024 * 1024;
let settings = { ...DEFAULT_SETTINGS };
const tester = new SoundEngine();
let testing = false;

async function load() {
  const { settings: s } = await chrome.storage.local.get('settings');
  settings = { ...DEFAULT_SETTINGS, ...(s || {}) };
}
async function save(patch) {
  await load(); // merge with anything the popup changed meanwhile
  settings = { ...settings, ...patch };
  await chrome.storage.local.set({ settings });
}

function render() {
  $('#default-minutes').value = settings.defaultMinutes;
  $('#chime').checked = settings.chime;
  $('#open-apps').checked = settings.openApps;
  $('#group-tabs').checked = settings.groupTabs;
  $('#lock-browsing').checked = settings.lockBrowsing;
  $('#allow-escape').checked = settings.allowEscape;
  $('#strict-mode').checked = settings.strictMode;
  if (document.activeElement !== $('#always-allowed')) $('#always-allowed').value = settings.alwaysAllowed.join('\n');
  $('#default-sound').value = settings.sound;
  $('#default-volume').value = Math.round(settings.volume * 100);

  const list = $('#saved-apps');
  list.replaceChildren(
    ...settings.recentApps.map((app, i) => {
      const li = document.createElement('li');
      const icon = app.type === 'web' ? Object.assign(document.createElement('img'), { src: faviconUrl(app.url), alt: '' }) : document.createElement('span');
      icon.className = 'fav';
      if (app.type !== 'web') icon.textContent = '🖥️';
      const name = Object.assign(document.createElement('span'), { className: 'name', textContent: app.name });
      const url = Object.assign(document.createElement('span'), { className: 'url', textContent: app.url || 'desktop reminder' });
      const x = Object.assign(document.createElement('button'), { className: 'x', textContent: '×', title: 'Remove' });
      x.addEventListener('click', () => {
        const recentApps = settings.recentApps.filter((_, j) => j !== i);
        save({ recentApps }).then(render);
      });
      li.append(icon, name, url, x);
      return li;
    }),
  );
  $('#saved-empty').hidden = settings.recentApps.length > 0;
}

async function renderCustom() {
  const rec = await getCustomAudio().catch(() => null);
  $('#custom-name').textContent = rec ? `${rec.name} (${(rec.blob.size / 1048576).toFixed(1)} MB)` : 'No file uploaded';
  $('#custom-remove').hidden = !rec;
  $('#custom-test').hidden = !rec;
}

function showError(msg) {
  $('#custom-error').textContent = msg;
  $('#custom-error').hidden = !msg;
}

async function init() {
  $('#default-sound').replaceChildren(
    ...SOUNDS.map((s) => Object.assign(document.createElement('option'), { value: s.id, textContent: `${s.icon}  ${s.name}` })),
  );
  await load();
  render();
  renderCustom();

  $('#default-minutes').addEventListener('change', (e) => {
    const m = Math.min(Math.max(Math.round(Number(e.target.value)) || 25, 1), 480);
    e.target.value = m;
    save({ defaultMinutes: m });
  });
  $('#chime').addEventListener('change', (e) => save({ chime: e.target.checked }));
  $('#open-apps').addEventListener('change', (e) => save({ openApps: e.target.checked }));
  $('#group-tabs').addEventListener('change', (e) => save({ groupTabs: e.target.checked }));
  $('#lock-browsing').addEventListener('change', (e) => save({ lockBrowsing: e.target.checked }));
  $('#allow-escape').addEventListener('change', (e) => save({ allowEscape: e.target.checked }));
  $('#strict-mode').addEventListener('change', (e) => save({ strictMode: e.target.checked }));
  chrome.extension.isAllowedIncognitoAccess().then((ok) => {
    $('#incog-status').textContent = ok
      ? '✅ Incognito windows are covered by focus lock.'
      : '⚠️ Incognito windows are NOT covered. Turn on "Allow in Incognito" for Focus Planner at chrome://extensions to close that loophole.';
  });
  $('#always-allowed').addEventListener('change', (e) => {
    const alwaysAllowed = [...new Set(e.target.value.split(/[\s,]+/).map(normalizeHost).filter(Boolean))];
    e.target.value = alwaysAllowed.join('\n');
    save({ alwaysAllowed });
  });
  $('#default-sound').addEventListener('change', (e) => save({ sound: e.target.value }));
  $('#default-volume').addEventListener('change', (e) => save({ volume: Number(e.target.value) / 100 }));

  $('#custom-file').addEventListener('change', async (e) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    if (!file.type.startsWith('audio/')) return showError('That file is not an audio file.');
    if (file.size > MAX_BYTES) return showError('That file is over 100 MB — try a shorter or compressed version.');
    showError('');
    await saveCustomAudio(file);
    await save({ sound: 'custom' });
    render();
    renderCustom();
  });
  $('#custom-remove').addEventListener('click', async () => {
    tester.stop();
    await clearCustomAudio();
    if (settings.sound === 'custom') await save({ sound: 'rain' });
    render();
    renderCustom();
  });
  $('#custom-test').addEventListener('click', async () => {
    if (testing) {
      tester.stop();
      testing = false;
      $('#custom-test').textContent = '▶ Test';
      return;
    }
    const res = await tester.play('custom', settings.volume);
    if (!res.ok) return showError(res.error);
    testing = true;
    $('#custom-test').textContent = '■ Stop';
  });

  $('#export-history').addEventListener('click', async () => {
    const { history = [] } = await chrome.storage.local.get('history');
    const esc = (v) => `"${String(v).replace(/"/g, '""')}"`;
    const rows = [
      ['task', 'outcome', 'focused_minutes', 'planned_minutes', 'apps', 'started', 'ended'],
      ...history.map((h) => [
        h.task,
        h.outcome,
        Math.round(h.focusedMs / 60000),
        Math.round(h.plannedMs / 60000),
        (h.apps || []).join('; '),
        new Date(h.startedAt).toISOString(),
        new Date(h.endedAt).toISOString(),
      ]),
    ];
    const blob = new Blob([rows.map((r) => r.map(esc).join(',')).join('\n')], { type: 'text/csv' });
    const a = Object.assign(document.createElement('a'), { href: URL.createObjectURL(blob), download: 'focus-history.csv' });
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 1000);
    $('#data-status').textContent = `Exported ${history.length} sessions.`;
  });
  $('#clear-history').addEventListener('click', async () => {
    const btn = $('#clear-history');
    if (btn.dataset.confirm !== '1') {
      btn.dataset.confirm = '1';
      btn.textContent = 'Click again to confirm';
      setTimeout(() => {
        btn.dataset.confirm = '';
        btn.textContent = 'Clear history';
      }, 4000);
      return;
    }
    await chrome.storage.local.set({ history: [] });
    btn.dataset.confirm = '';
    btn.textContent = 'Clear history';
    $('#data-status').textContent = 'History cleared.';
  });

  chrome.storage.onChanged.addListener((c, area) => {
    if (area === 'local' && c.settings) {
      settings = { ...DEFAULT_SETTINGS, ...(c.settings.newValue || {}) };
      render();
    }
  });
}

init();
