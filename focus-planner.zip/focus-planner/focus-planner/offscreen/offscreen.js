// Hidden page that plays the focus sounds. Service workers can't play
// audio, so the background script drives this document by message.
import { SoundEngine } from '../lib/sounds.js';

const engine = new SoundEngine();

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg?.target !== 'offscreen') return;
  (async () => {
    let result = { ok: true };
    switch (msg.type) {
      case 'play':
        result = await engine.play(msg.sound, msg.volume);
        break;
      case 'stop':
        engine.stop();
        break;
      case 'volume':
        engine.setVolume(msg.volume);
        break;
      case 'chime':
        engine.chime(msg.volume);
        break;
    }
    sendResponse({ ...result, audioState: engine.state, current: engine.current });
  })().catch((e) => sendResponse({ ok: false, error: String(e?.message || e) }));
  return true;
});
