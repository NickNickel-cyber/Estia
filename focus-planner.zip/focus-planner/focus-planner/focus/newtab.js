// Replaces Chrome's new tab page while a locked focus session is running.
import { isLockActive } from '../lib/lock.js';
import { faviconUrl } from '../lib/apps.js';

const $ = (s) => document.querySelector(s);
let session = null;

function fmt(ms) {
  const t = Math.ceil(ms / 1000);
  const h = Math.floor(t / 3600);
  const m = Math.floor((t % 3600) / 60);
  return `${h ? `${h}:` : ''}${h ? String(m).padStart(2, '0') : m}:${String(t % 60).padStart(2, '0')}`;
}

function render() {
  if (!isLockActive(session)) {
    // The background swaps this back to Chrome's new tab page when the lock ends.
    $('#headline').textContent = 'Focus lock is off';
    $('#task').textContent = 'You can browse freely again';
    $('#time').textContent = '';
    return;
  }
  document.title = `New tab · ${session.task}`;
  $('#task').textContent = session.task;
  const web = (session.apps || []).filter((a) => a.type === 'web' && a.url);
  $('#tiles').replaceChildren(
    ...web.map((app) => {
      const a = document.createElement('a');
      a.className = 'tile';
      a.href = app.url;
      const img = Object.assign(document.createElement('img'), { src: faviconUrl(app.url, 64), alt: '' });
      const name = Object.assign(document.createElement('span'), { textContent: app.name });
      a.append(img, name);
      return a;
    }),
  );
  $('#no-apps').hidden = web.length > 0;
  const desktop = (session.apps || []).filter((a) => a.type === 'desktop');
  $('#desktop-panel').hidden = desktop.length === 0;
  $('#desktop').replaceChildren(...desktop.map((a) => Object.assign(document.createElement('li'), { textContent: `🖥️ ${a.name}` })));
  $('#foot').textContent = session.strict
    ? 'Strict focus is on. Everything unlocks when the timer ends.'
    : 'Need a break? Click the Focus Planner icon in your toolbar to pause.';
  tick();
}

function tick() {
  if (isLockActive(session)) $('#time').textContent = fmt(Math.max(0, session.endsAt - Date.now()));
}

const { session: s } = await chrome.storage.local.get('session');
session = s || null;
render();
setInterval(tick, 500);
chrome.storage.onChanged.addListener((c, area) => {
  if (area === 'local' && c.session) {
    session = c.session.newValue || null;
    render();
  }
});
