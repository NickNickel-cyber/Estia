// Shown instead of an off-limits site while a locked focus session runs.
// The background script restores or closes this page when the session
// pauses or ends.
import { hostOf, isLockActive } from '../lib/lock.js';
import { DEFAULT_SETTINGS } from '../lib/defaults.js';

const $ = (s) => document.querySelector(s);
const params = new URLSearchParams(location.search);
const blockedUrl = params.get('url') || '';
const mode = params.get('mode'); // 'nav' = you tried to go here; 'tab' = you switched to this tab
const isWeb = /^https?:/i.test(blockedUrl);
const host = isWeb ? hostOf(blockedUrl) : '';
const send = (type, data = {}) => chrome.runtime.sendMessage({ target: 'background', type, ...data });

let session = null;
let settings = DEFAULT_SETTINGS;

function fmt(ms) {
  const t = Math.ceil(ms / 1000);
  const h = Math.floor(t / 3600);
  const m = Math.floor((t % 3600) / 60);
  return `${h ? `${h}:` : ''}${h ? String(m).padStart(2, '0') : m}:${String(t % 60).padStart(2, '0')}`;
}

function render() {
  if (!isLockActive(session)) {
    // Session paused or ended — the background will restore this tab; this is a fallback.
    $('#headline').textContent = 'Focus lock is off';
    $('#task').textContent = 'You can browse freely again';
    $('#time').textContent = '';
    $('#reason').textContent = '';
    $('#back').textContent = host ? `Continue to ${host}` : 'Close';
    $('#allow').hidden = true;
    $('#allowed-panel').hidden = true;
    return;
  }
  $('#task').textContent = session.task;
  document.title = `Stay focused: ${session.task}`;
  const site = host ? `<span class="site">${host.replace(/[<>&]/g, '')}</span>` : 'This page';
  $('#reason').innerHTML = !isWeb
    ? "Chrome's settings, extension and file pages are locked during strict focus."
    : mode === 'tab'
      ? `That tab (${site}) is off-limits until your focus session ends.`
      : `${site} isn't one of your apps for this session.`;
  const canAllow = settings.allowEscape && !session.strict && !!host;
  $('#allow').hidden = !canAllow;
  $('#allow').textContent = `Allow ${host} for this session`;
  const hosts = session.allowedHosts || [];
  $('#allowed-panel').hidden = hosts.length === 0;
  $('#allowed').replaceChildren(...hosts.map((h) => Object.assign(document.createElement('li'), { textContent: h })));
  $('#foot').textContent = session.strict
    ? 'Strict focus is on: this unlocks when the timer ends.'
    : 'Need to stop? Click the Focus Planner icon in your toolbar to pause or end the session.';
  tick();
}

function tick() {
  if (!isLockActive(session)) return;
  $('#time').textContent = fmt(Math.max(0, session.endsAt - Date.now()));
}

async function init() {
  const stored = await chrome.storage.local.get(['session', 'settings']);
  session = stored.session || null;
  settings = { ...DEFAULT_SETTINGS, ...(stored.settings || {}) };
  render();
  setInterval(tick, 500);
  chrome.storage.onChanged.addListener((c, area) => {
    if (area !== 'local') return;
    if (c.session) session = c.session.newValue || null;
    if (c.settings) settings = { ...DEFAULT_SETTINGS, ...(c.settings.newValue || {}) };
    if (c.session || c.settings) render();
  });

  $('#back').addEventListener('click', async () => {
    if (!isLockActive(session)) {
      if (mode === 'nav' && blockedUrl) location.replace(blockedUrl);
      else window.close();
      return;
    }
    await send('backToWork');
  });

  let armed = false;
  $('#allow').addEventListener('click', async () => {
    // Two clicks, so allowing a distraction is a conscious choice.
    if (!armed) {
      armed = true;
      $('#allow').textContent = `Sure? Click again to allow ${host}`;
      setTimeout(() => {
        armed = false;
        render();
      }, 4000);
      return;
    }
    const res = await send('allowHost', { host });
    if (!res?.ok) render();
  });
}

init();
